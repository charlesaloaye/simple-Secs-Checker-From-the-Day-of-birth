
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta content="IE=edge,chrome=1" http-equiv="X-UA-Compatible">
<meta name="viewport"  content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="Css/bootstrap.min.css">
<title>
Date spent
</title>
</head>
<body  style="margin:35px;">
<?php include"form.php";?>
</body>
</html>