<div class="container">
<div class="row">
<div class="col-xs-12 col-sm-12 col-md-4 col-lg-4"></div>

<div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
<h3 align="center" style="color:gray;"><?php echo ucwords("check time spent");?></h3>

<?php include"validations.php";?>
<form method="post" actoion="" style="margin:35px;">

<div class="form-group">
	<input type="text" class="form-control" placeholder="Name"  name="user_name" value="<?php echo @$name;?>">
</div>

<div class="form-group">
	<input type="text" class="form-control" placeholder="Date"  name="user_date" value="<?php echo @$date;?>">
</div>

<div class="form-group">
	<input type="text" class="form-control" placeholder="Month"  name="user_month" value="<?php echo @$month;?>">
	</div>

<div class="form-group">
	<input type="text" class="form-control" placeholder="Year"  name="user_year" value="<?php echo @$year;?>">
</div>

<div class="form-group">
	<?php
	if(isset($_POST["check_time_spent"]))
		{

		$email = filter_var($email,FILTER_SANITIZE_EMAIL);		
		$email = filter_var($email,FILTER_VALIDATE_EMAIL);

	if(!$email)
	{
		echo "sorry ".$_POST["user_email"]." is not a valid email id@we are unable to email you the details";
	}
	}
	?>
	<input type="text" class="form-control" placeholder="Email"  name="user_email" value="<?php echo @$email;?>">
</div>

<button type="submit" class="btn btn-outline-primary btn-block" name="check_time_spent">Check Time spent</button>
</form>
</div>
<div class="col-xs-12 col-sm-12 col-md-4 col-lg-4"></div>
</div>
</div>
