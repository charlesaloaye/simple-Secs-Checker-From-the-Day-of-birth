<?php
if(isset($_POST["check_time_spent"]))

{



	$name =  $_POST["user_name" ];
	$date = $_POST["user_date" ];
	$month = $_POST["user_month"];
	$year = $_POST["user_year"];
	$email =  $_POST["user_email" ];
	$secs_spent = @mktime(10,14,54,$date,$month,$year);

$subject = "Date Creation details are given below<br/> " .
"name :" . $name ."<br/>Date of birth : ".$date. "<br/> Month of birth :"
.$month."year of birth :"  .$year."Total time spent :"
.$timestamp."<br/>you're currently".$age;
$from ="aloayecharles@gmail.com";
$to= $_POST["user_email" ];
$headers="<h1>DATE SPENT CREATION</h1>";
$y = date("Y");
$age = $y-$_POST["user_year"];

 if($name  =="" || 	$date  ==""  ||  $month==""  || $year=="")

{ 
	echo'<script> alert("all fields must be entered")</script>';

}

else{
mail($from,$to,$subject,$headers);
echo '
<div class="container">
<div class="alert alert-success">
<div class="row">
<div class="col-xs-12 col-sm-12 col-md-10 col-lg-10"></div>
<div class="col-xs-12 col-sm-12 col-md-10 col-lg-10">
	Dear <b>'
 . $name . '</b> you have spent ' . $secs_spent. ' secs currently';
echo " and your are $age years old 
</div>
</div>
</div>

<div class='col-xs-12 col-sm-12 col-md-10 col-lg-10'></div>
</div>";
}
}
?>